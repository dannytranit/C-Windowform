﻿namespace UserRating
{
    partial class LoginScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernameInputText = new System.Windows.Forms.TextBox();
            this.UsernameLb = new System.Windows.Forms.Label();
            this.PasswordLb = new System.Windows.Forms.Label();
            this.Loginbtn = new System.Windows.Forms.Button();
            this.Cancelbtn = new System.Windows.Forms.Button();
            this.passwordInputText = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // usernameInputText
            // 
            this.usernameInputText.Cursor = System.Windows.Forms.Cursors.Default;
            this.usernameInputText.Location = new System.Drawing.Point(450, 96);
            this.usernameInputText.Name = "usernameInputText";
            this.usernameInputText.Size = new System.Drawing.Size(222, 20);
            this.usernameInputText.TabIndex = 1;
            // 
            // UsernameLb
            // 
            this.UsernameLb.AutoSize = true;
            this.UsernameLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameLb.Location = new System.Drawing.Point(349, 98);
            this.UsernameLb.Name = "UsernameLb";
            this.UsernameLb.Size = new System.Drawing.Size(81, 18);
            this.UsernameLb.TabIndex = 1;
            this.UsernameLb.Text = "User name";
            this.UsernameLb.UseWaitCursor = true;
            // 
            // PasswordLb
            // 
            this.PasswordLb.AutoSize = true;
            this.PasswordLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLb.Location = new System.Drawing.Point(349, 164);
            this.PasswordLb.Name = "PasswordLb";
            this.PasswordLb.Size = new System.Drawing.Size(75, 18);
            this.PasswordLb.TabIndex = 1;
            this.PasswordLb.Text = "Password";
            this.PasswordLb.UseWaitCursor = true;
            // 
            // Loginbtn
            // 
            this.Loginbtn.Cursor = System.Windows.Forms.Cursors.Default;
            this.Loginbtn.Location = new System.Drawing.Point(466, 237);
            this.Loginbtn.Name = "Loginbtn";
            this.Loginbtn.Size = new System.Drawing.Size(75, 23);
            this.Loginbtn.TabIndex = 2;
            this.Loginbtn.Text = "Login";
            this.Loginbtn.UseVisualStyleBackColor = true;
            this.Loginbtn.Click += new System.EventHandler(this.LoginBtn_Click);
            // 
            // Cancelbtn
            // 
            this.Cancelbtn.Location = new System.Drawing.Point(580, 237);
            this.Cancelbtn.Name = "Cancelbtn";
            this.Cancelbtn.Size = new System.Drawing.Size(75, 23);
            this.Cancelbtn.TabIndex = 3;
            this.Cancelbtn.Text = "New User";
            this.Cancelbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Cancelbtn.UseVisualStyleBackColor = true;
            this.Cancelbtn.Click += new System.EventHandler(this.NewUserBtn_Click);
            // 
            // passwordInputText
            // 
            this.passwordInputText.Cursor = System.Windows.Forms.Cursors.Default;
            this.passwordInputText.Location = new System.Drawing.Point(450, 162);
            this.passwordInputText.Name = "passwordInputText";
            this.passwordInputText.Size = new System.Drawing.Size(222, 20);
            this.passwordInputText.TabIndex = 2;
            this.passwordInputText.UseSystemPasswordChar = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UserRating.Properties.Resources.Relationship_icon;
            this.pictureBox1.Location = new System.Drawing.Point(15, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(278, 271);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // LoginScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(684, 296);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.passwordInputText);
            this.Controls.Add(this.Cancelbtn);
            this.Controls.Add(this.Loginbtn);
            this.Controls.Add(this.PasswordLb);
            this.Controls.Add(this.UsernameLb);
            this.Controls.Add(this.usernameInputText);
            this.Name = "LoginScreen";
            this.Text = "Login Screen";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox usernameInputText;
        private System.Windows.Forms.Label UsernameLb;
        private System.Windows.Forms.Label PasswordLb;
        private System.Windows.Forms.Button Loginbtn;
        private System.Windows.Forms.Button Cancelbtn;
        private System.Windows.Forms.TextBox passwordInputText;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

