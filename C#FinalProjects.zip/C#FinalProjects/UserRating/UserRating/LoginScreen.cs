﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserRating
{
    public partial class LoginScreen : Form
    {     
        UserHandler userHandler = new UserHandler();
        User loggedInUser;
        List<User> userList;
        public LoginScreen()
        {        
            InitializeComponent();       
            if (userHandler.LoadAllUser())
            {
                userHandler.LoadAllUser();
                userList = userHandler.GetUserList();             
            }
            else
                MessageBox.Show("User data can not be loaded", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

         private void NewUserBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewUserScreen newUserScreen = new NewUserScreen(userList);
            newUserScreen.Show();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = usernameInputText.Text;
            string password = passwordInputText.Text;
            if (userHandler.FindUser(username, password) != null)
            {
                this.Hide();
                loggedInUser = userHandler.FindUser(username, password);
                UserListScreen userListScreen = new UserListScreen(loggedInUser, userList);
                userListScreen.Show();
            }
            else
                MessageBox.Show("Incorrect username or password", "Login");
        }       
    }
}
