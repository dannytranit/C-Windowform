﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace UserRating
{
    class Admin : User
    {
        public enum AdminType
        {
            SuperAdmin,
            Moderator
        }
        private AdminType adminType { get; set; }
        public Admin(string username, string password, string firstName, string lastName, AdminType adminType, int ratingsCount, double averageRating)
        {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.adminType = adminType;
            this.ratingsCount = ratingsCount;
            this.averageRating = averageRating;
        }
        public bool WriteAdmintoFile()
        {
            bool isAdminSaved = false;
            StreamWriter writer = new StreamWriter("Admin.txt", true);       
            if (writer.BaseStream != null)
            {
                string text = username + "," + password + "," + firstName + "," + lastName + "," + adminType.ToString() + "," + ratingsCount + "," + averageRating;
                writer.WriteLine(text);
                MessageBox.Show("Admin data is saved successfully");
                isAdminSaved = true;                   
            }
            else
            {
                MessageBox.Show("Admin.txt is not existed");                            
            }
            writer.Close();
            return isAdminSaved;
        }

        public void RemoveAdminfromFile()
        {
            var tempFile = Path.GetTempFileName();
            var linesToKeep = File.ReadAllLines("Admin.txt").Where(l => l.Contains(username) == false);
            File.WriteAllLines(tempFile, linesToKeep);
            File.Delete("Admin.txt");
            File.Move(tempFile, "Admin.txt");
        }
        public override string GettFullUserString()
        {
            string str;
            return
                str = firstName + " " + lastName + " " + adminType;
        }
        public AdminType GetAdminType()
        {
            return adminType;
        }


    }

}
