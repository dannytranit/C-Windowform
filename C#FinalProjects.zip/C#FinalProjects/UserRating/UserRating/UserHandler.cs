﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;


namespace UserRating
{
    class UserHandler
    {
        private List<User> userList;
        private User loggedInUser;
        public User LoggedInUser { get { return loggedInUser; } set { LoggedInUser = loggedInUser; } }
        public bool LoadAllUser()
        {          
            string username;
            string password;
            string firstName;
            string lastName;
            int ratingsCount;
            double averageRating;
            bool isUserLoaded = false;
            userList = new List<User>();
            StreamReader adFileReader = new StreamReader("Admin.txt");
            StreamReader guFileReader = new StreamReader("Guest.txt");            
            if (adFileReader.BaseStream != null&& guFileReader.BaseStream != null)
            {
                while (!adFileReader.EndOfStream)
                {                   
                    Admin.AdminType adminType;
                    string text = adFileReader.ReadLine();
                    string[] strings = text.Split(',');
                    username = strings[0];
                    password = strings[1];
                    firstName = strings[2];
                    lastName = strings[3];
                    if (strings[4] == "SuperAdmin")
                    {
                        adminType = Admin.AdminType.SuperAdmin;
                    }
                    else
                        adminType = Admin.AdminType.Moderator;
                    ratingsCount = Convert.ToInt32(strings[5]);
                    averageRating = Convert.ToDouble(strings[6]);
                    Admin admin = new Admin(username, password, firstName, lastName, adminType, ratingsCount, averageRating);
                    userList.Add(admin);                  
                }
                adFileReader.Close();
                while (!guFileReader.EndOfStream)
                {               
                    DateTime dateOfBirth;
                    string text = guFileReader.ReadLine();
                    string[] strings = text.Split(',');
                    username = strings[0];
                    password = strings[1];
                    firstName = strings[2];
                    lastName = strings[3];                  
                    dateOfBirth = Convert.ToDateTime(strings[4]);
                    ratingsCount = Convert.ToInt32(strings[5]);
                    averageRating = Convert.ToDouble(strings[6]);
                    Guest guest = new Guest(username, password, firstName, lastName, dateOfBirth, ratingsCount, averageRating);
                    userList.Add(guest);                   
                }
                guFileReader.Close();
                isUserLoaded = true;
            }
            return isUserLoaded;
        }
        public List<User> GetUserList()
        {
           return userList;           
        }
        public User FindUser(string username, string password)
        {
            foreach (User user in userList)
            {
                if (user.CheckUserNameAndPassword(username, password))
                {
                    loggedInUser = user;
                    break;
                }             
            }
            return loggedInUser;
        }      
        public bool SaveAllUser (User user)
        {
            bool isUserSaved;

            if (user is Admin)
            {
                Admin admin = (Admin)user;
                isUserSaved = admin.WriteAdmintoFile();        
            }
            else
            {
                Guest guest = (Guest)user;
                isUserSaved = guest.WriteGuesttoFile();            
            }
            return isUserSaved;
       }

        public void RemoveAllUser(User user)
        {
            if (user is Admin)
            {
                Admin admin = (Admin)user;
                admin.RemoveAdminfromFile();
            }
            else
            {
                Guest guest = (Guest)user;
                guest.RemoveGuestfromFile();
            }
        }
    }
}
