﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserRating
{

    public partial class NewUserScreen : Form
    {
        LoginScreen loginScreen;
        UserHandler userHandler;
        List<User> userList;
        ErrorProvider errorProvider;
        public NewUserScreen(List<User> userList)
        {
            InitializeComponent();
            userHandler = new UserHandler();
            errorProvider = new ErrorProvider();
            this.userList = userList;
        }
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            string username = userNameInput.Text;
            string password = passwordInput.Text;
            string lastName = lastNameInput.Text;
            string firstName = firstNameInput.Text;
            DateTime dateOfBirth = dateTimePicker.Value;
            string DateOfBirth = dateOfBirth.ToShortDateString();
            DateOfBirth = DateOfBirth.Replace('/', '-');

            User user = new Guest(username, password, firstName, lastName, dateOfBirth, 0, 0);
            userHandler.SaveAllUser(user);
            this.Hide();
            loginScreen = new LoginScreen();
            loginScreen.Show();
        }
        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginScreen = new LoginScreen();
            loginScreen.Show();
        }
        private void userNameInput_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsLetterOrDigit(ch) || char.IsControl(ch))
            {
                e.Handled = false;
            }
            else
            {
                MessageBox.Show("User can have English alphabet characters and number but not have symbols and whitespace", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }
        private void passwordInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsLetterOrDigit(ch) || char.IsControl(ch))
            {
                e.Handled = false;

            }
            else
            {
                MessageBox.Show("Password can have English alphabet characters and number but not have symbols and whitespace", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }
        private void firstNameInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsLetter(ch) || char.IsControl(ch))
            {
                e.Handled = false;
            }
            else
            {
                MessageBox.Show("Firstname can only have English alphabet characters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                e.Handled = true;
            }
        }
        private void lastNameInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (char.IsSymbol(ch) || char.IsWhiteSpace(ch) || char.IsDigit(ch))
            {
                e.Handled = false;
                MessageBox.Show("Lastname can only have English alphabet characters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        private void firstNameInput_TextChanged(object sender, EventArgs e)
        {
            firstNameInput.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(firstNameInput.Text);
            firstNameInput.Select(firstNameInput.Text.Length, 0);
        }

        private void lastNameInput_TextChanged(object sender, EventArgs e)
        {
            lastNameInput.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(lastNameInput.Text);
            lastNameInput.Select(lastNameInput.Text.Length, 0);
        }

        private void userNameInput_Validating(object sender, CancelEventArgs e)
        {
            string username = userNameInput.Text;
            bool isValid = username.Length < 2;
            if (isValid)
            {
                e.Cancel = true;
                userNameInput.Select(0, username.Length);
                errorProvider.SetError(userNameInput, "Username needs to have a minimum of 2 character");
            }

            if (CheckUserName(username, userList))
            {
                e.Cancel = true;
                userNameInput.Select(0, userNameInput.Text.Length);
                errorProvider.SetError(userNameInput, "Username has existed, please enter a new username");
            }
        }
        
        private void passwordInput_Validating(object sender, CancelEventArgs e)
        {
            string password = passwordInput.Text;
            bool isValid = password.Length < 2;
            if (isValid)
            {
                e.Cancel = true;
                userNameInput.Select(0, password.Length);
                errorProvider.SetError(passwordInput, "Password needs to have a minimum of 2 character");
            }
        }
        private void firstNameInput_Validating(object sender, CancelEventArgs e)
        {
            string firstName = firstNameInput.Text;
            bool isValid = firstName.Length < 2;
            if (isValid)
            {
                e.Cancel = true;
                userNameInput.Select(0, firstName.Length);
                errorProvider.SetError(firstNameInput, "FirstName needs to have a minimum of 2 character");
            }
        }
        private void lastNameInput_Validating(object sender, CancelEventArgs e)
        {
            string lastName = lastNameInput.Text;
            bool isValid = lastName.Length < 2;
            if (isValid)
            {
                e.Cancel = true;
                userNameInput.Select(0, lastName.Length);
                errorProvider.SetError(lastNameInput, "Lastname needs to have a minimum of 2 character");
            }
        }
        private void userNameInput_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(userNameInput, "");
        }
        private void passwordInput_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(passwordInput, "");
        }

        private void firstNameInput_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(firstNameInput, "");
        }
        private void lastNameInput_Validated(object sender, EventArgs e)
        {
            errorProvider.SetError(lastNameInput, "");
        }
        public bool CheckUserName(string username, List<User> userList)
        {
            bool isUserNameFound = false;
            foreach (User user in userList)
            {
                if (user.CheckUserName(username))
                {
                    isUserNameFound = true;
                    break;
                }
            }
            return isUserNameFound;
        }
    }
}
