﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserRating
{
    public partial class UserRatingDialog : Form
    {
        List<User> ratedUserList;
        List<User> userList;
        User loggedInUser;
        UserListScreen userListScreen;
        public UserRatingDialog(List<User> ratedUserList, List<User> userList, User loggedInUser)
        {
            InitializeComponent();
            this.ratedUserList = ratedUserList;
            this.userList = userList;
            this.loggedInUser = loggedInUser;       
        }
        private void submitBtn_Click(object sender, EventArgs e)
        {
            UserHandler userHandler = new UserHandler();        
            var radSelected = this.Controls.OfType<RadioButton>()
                           .FirstOrDefault(n => n.Checked);
            int ratedValue = Convert.ToInt32(radSelected.Text);
            for (int i = 0; i < ratedUserList.Count; i++)
            {         
                userHandler.RemoveAllUser(ratedUserList[i]);
                ratedUserList[i].AddRating(ratedValue);
                userHandler.SaveAllUser(ratedUserList[i]);               
            }
            this.Hide();
            userListScreen = new UserListScreen(loggedInUser, userList);
            userListScreen.Show();          
        }
        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            userListScreen = new UserListScreen(loggedInUser, userList);
            userListScreen.Show();
        }
    }
}
