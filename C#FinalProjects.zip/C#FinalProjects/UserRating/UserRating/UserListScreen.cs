﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserRating
{
    
    public partial class UserListScreen : Form
    {
         
        List<User> selectedUserList;
        List<User> userList;
        User loggedInUser;
        List<User> newUserList;


        public UserListScreen(User loggedInUser, List<User> userList)
        {          
            InitializeComponent();         
            this.loggedInUser = loggedInUser;        
            this.userList = userList;
            selectedUserList = new List<User>();
            newUserList = new List<User>();
        }
        private void UserListScreen_Load(object sender, EventArgs e)
        {

            List<CheckBox> checkBoxs = new List<CheckBox>() { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7, checkBox8, checkBox9, checkBox10,
                                                              checkBox11, checkBox12, checkBox13, checkBox14, checkBox15, checkBox16, checkBox17, checkBox18, checkBox19, checkBox20,
                                                              checkBox21, checkBox22, checkBox23, checkBox24, checkBox25, checkBox26, checkBox27, checkBox28, checkBox29, checkBox30,
                                                              checkBox31, checkBox32, checkBox33, checkBox34};
            List<TextBox> ratingNumberTextBoxs = new List<TextBox>() { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7, textBox8, textBox9, textBox10,
                                                                       textBox11, textBox12, textBox13, textBox14, textBox15, textBox16, textBox17, textBox18, textBox19, textBox20,
                                                                       textBox21, textBox22, textBox23, textBox24, textBox25, textBox26, textBox27, textBox28, textBox29, textBox30,
                                                                       textBox31, textBox32, textBox33, textBox34};
            List<TextBox> averageRatingTextBoxs = new List<TextBox>() { textBox41, textBox42, textBox43, textBox44, textBox45, textBox46, textBox47, textBox48, textBox49, textBox50,
                                                                        textBox51, textBox52, textBox53, textBox54, textBox55, textBox56, textBox57, textBox58, textBox59, textBox60,
                                                                        textBox61, textBox62, textBox63, textBox64, textBox65, textBox66, textBox67, textBox68, textBox69, textBox70,
                                                                        textBox71, textBox72, textBox73, textBox74};       
            loggedInUserText.Text = loggedInUser.GettFullUserString();         
            foreach (User user in userList)
            {
                if (user != loggedInUser)
                    newUserList.Add(user);
            }
            try
            {
                if (loggedInUser is Admin)
                {
                    Admin admin = (Admin)loggedInUser;
                    if (admin.GetAdminType() == Admin.AdminType.Moderator)
                    {
                        makeUsersAdminBtn.Hide();
                    }
                    for (int i = 0; i < newUserList.Count; i++)
                    {
                        checkBoxs[i].Text = newUserList[i].GettFullUserString();
                        ratingNumberTextBoxs[i].Text = newUserList[i].RatingsCount.ToString();
                        averageRatingTextBoxs[i].Text = newUserList[i].AverageRating.ToString();
                    }
                    for (int j = newUserList.Count; j < checkBoxs.Count; j++)
                    {
                        checkBoxs[j].Hide();
                        ratingNumberTextBoxs[j].Hide();
                        averageRatingTextBoxs[j].Hide();
                    }
                }
                else
                {
                    List<User> guestList = new List<User>();
                    makeUsersAdminBtn.Hide();
                    for (int i = 0; i < newUserList.Count; i++)
                    {
                        if (!(newUserList[i] is Admin))
                        {
                            guestList.Add(newUserList[i]);
                        }
                    }
                    for (int i = 0; i < guestList.Count; i++)
                    {
                        checkBoxs[i].Text = guestList[i].GettFullUserString();
                        ratingNumberTextBoxs[i].Text = guestList[i].RatingsCount.ToString();
                        averageRatingTextBoxs[i].Text = guestList[i].AverageRating.ToString();
                    }
                    for (int j = guestList.Count; j < checkBoxs.Count; j++)
                    {
                        checkBoxs[j].Hide();
                        ratingNumberTextBoxs[j].Hide();
                        averageRatingTextBoxs[j].Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception Error");
            }
        }
        private void makeUsersAdminBtn_Click(object sender, EventArgs e)
        {
            GetSelectedUserList();
            if (selectedUserList.Count ==0)
            {
                MessageBox.Show("Users have not been choosen, please choose a user(s)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                this.Hide();
                MakeUserAdmin makeUserAdmin = new MakeUserAdmin(selectedUserList, newUserList, loggedInUser);
                makeUserAdmin.Show();
            }      
        }
        private void provideRatingtoUserBtn_Click(object sender, EventArgs e)
        {
            GetSelectedUserList();
            if (selectedUserList.Count == 0)
            {
                MessageBox.Show("Users have not been choosen, please choose a user(s)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                this.Hide();
                UserRatingDialog userRatingDialog = new UserRatingDialog(selectedUserList, newUserList, loggedInUser);
                userRatingDialog.Show();
            }
        }

        public List<User> GetSelectedUserList()
        {          
           List<string> textList = panel1.Controls.OfType<CheckBox>().Where (n => n.Checked).Select(n =>n.Text).ToList();
            
           foreach (String text in textList)
           {            
                foreach (User user in newUserList)
                {
                    if (user.GettFullUserString() == text)
                    {
                        selectedUserList.Add(user);
                        break;
                    } 
                }
           }        
          return selectedUserList;          
        }       
    }
}
