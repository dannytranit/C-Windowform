﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserRating
{
    public partial class MakeUserAdmin : Form
    {

        List<User> newUserList;
        List<User> userList;
        User loggedInUser;
        UserListScreen userListScreen;
        public MakeUserAdmin(List<User> newUserList, List <User> userList, User loggedInUser)
        {
            InitializeComponent();
            this.newUserList = newUserList;
            this.userList = userList;
            this.loggedInUser = loggedInUser;        
        }
            
        private void adminTypeDropList_SelectedIndexChanged(object sender, EventArgs e)
        {
            adminTypeDropList.Text = adminTypeDropList.SelectedItem.ToString();
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            UserHandler userHandler = new UserHandler();
            for (int i = 0; i < newUserList.Count; i++)
            {
                Guest guest = (Guest)newUserList[i];
                guest.RemoveGuestfromFile();
                if (adminTypeDropList.Text == "")
                {
                    MessageBox.Show("A admin type is not choosen", "Test");
                } 
                else
                {
                    User user;
                    if (adminTypeDropList.Text == "SuperAdmin")
                        user = guest.SetGuestToAdmin("SuperAdmin");
                    else
                        user = guest.SetGuestToAdmin("Moderator");
                    userHandler.SaveAllUser(user);
                }              
            }
            if (userHandler.LoadAllUser())
            {
                userHandler.LoadAllUser();
                userList = userHandler.GetUserList();
            }
            else
                MessageBox.Show("User data can not be loaded", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            this.Hide();
            userListScreen = new UserListScreen(loggedInUser, userList);
            userListScreen.Show();
        }
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            userListScreen = new UserListScreen(loggedInUser, userList);
            userListScreen.Show();
        }
    }
}
