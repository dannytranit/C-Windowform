﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace UserRating
{
    class Guest : User
    {
        private DateTime dateOfBirth;
        public Guest(string username, string password, string firstName, string lastName, DateTime dateOfBirth, int ratingsCount, double averageRating)
        {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
            this.dateOfBirth = dateOfBirth;
            this.ratingsCount = ratingsCount;
            this.averageRating = averageRating;
        }
        public bool WriteGuesttoFile()
        {
            bool isGuestSaved = false;
            StreamWriter writer = new StreamWriter("Guest.txt", true);
            if (writer.BaseStream != null)
            {
                string text = username + "," + password + "," + firstName + "," + lastName + "," + dateOfBirth.ToShortDateString().Replace('/', '-') + "," + ratingsCount + "," + averageRating;
                writer.WriteLine(text);
                MessageBox.Show("Guest data is saved successfully", "DataManager", MessageBoxButtons.OK, MessageBoxIcon.None);
                isGuestSaved = true;
            }
           else
            {
                MessageBox.Show("Guest.txt is not existed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);              
            }
            writer.Close();
            return isGuestSaved;
        }
        public void RemoveGuestfromFile()
        {
            var tempFile = Path.GetTempFileName();
            var linesToKeep = File.ReadAllLines("Guest.txt").Where(l => l.Contains(username) == false);
            File.WriteAllLines(tempFile, linesToKeep);
            File.Delete("Guest.txt");
            File.Move(tempFile, "Guest.txt");                          
        }
        public User SetGuestToAdmin(string adType)
        {
            User user;
            Admin.AdminType adminType;
           
            if (adType == "SuperAdmin")
            {
                adminType = Admin.AdminType.SuperAdmin;
            }
            else
                adminType = Admin.AdminType.Moderator;
            user = new Admin(username, password, firstName, lastName, adminType, ratingsCount, averageRating);
            return user;
        }
        public override string GettFullUserString()
        {
            string str;
            return
                str = firstName + " " +lastName + " "+ dateOfBirth.ToShortDateString().Replace('/', '-');   
        }
    }
}
