﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRating
{
    public abstract class User
    {
        protected string username;
        protected string password;
        protected string firstName;
        protected string lastName;
        protected int ratingsCount;       
        public int RatingsCount { get { return ratingsCount; } }
        protected double averageRating;
        public double AverageRating { get { return averageRating; } }
        
        public bool CheckUserNameAndPassword(string _username, string _password)
        {
            if (username == _username && password == _password)
            {
                return true;
            }
            else
                return false;
        }
        public bool CheckUserName(string _username)
        {
            if (username == _username)
            {
                return true;
            }
            else
                return false;
        }
        public string GetShortUserString()
        {
            string str;
            return
                str = firstName+ " " + lastName;
        }
        public void AddRating(int rating)
        {
            averageRating = Math.Round((averageRating*ratingsCount + rating)/(1+ratingsCount), 2);
            ratingsCount++;
        }
        
        public abstract string GettFullUserString();     
    }
}
