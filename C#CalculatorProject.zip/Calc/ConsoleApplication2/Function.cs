﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Function
    {

        public int SolveSecondEqn (List<string> leftList, List<string> rightList)
        {
            int result = 0;
            int a, b;
            leftList=SimplifiseEqn(leftList);
            rightList = SimplifiseEqn(rightList);
            a = Convert.ToInt32(leftList[1]) - Convert.ToInt32(rightList[1]);
            b = Convert.ToInt32(rightList[0]) - Convert.ToInt32(leftList[0]);
            try
            {
                result = b / a;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }
            return result;

        }
        public List <string> SimplifiseEqn(List<string> list)
        {
            List<string> finalList = new List<string>();

            if (list[0]=="-")
            {
                list.Insert(0,"0");
            }
			if (list[list.Count - 1] =="+"|| list[list.Count - 1] =="-")
            {
                list.Insert(list.Count - 1, "0");
            }
            if (list.Contains("X"))
            {
                
                List<string> newList = new List<string>();
                for (int j = 0; j < list.Count; j++)
                {
                    if (j + 1 < list.Count && list[j] != "X" && list[j] != "*" && list[j] != "/" && list[j] != "+" && list[j] != "-" && list[j] != "%" && list[j + 1] != "X")
                    {
                        try
                        {
                            int number = Int32.Parse(list[j]);
                            newList.Add(list[j]);
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("{0}: Bad Format", list[j]);
                        }
                        catch (OverflowException)
                        {
                            Console.WriteLine("{0}: Overflow", list[j]);
                        }
                      

                    }
                    else if (j + 2 < list.Count && list[j + 2] != "X" && list[j + 1] != "X" && (list[j] == "*" || list[j] == "/" || list[j] == "+" || list[j] == "-" || list[j] == "%"))
                    {
                        newList.Add(list[j]);
                    }
                           
                }
				
               if (list.Count - 2 > 0 && (list[list.Count - 2] == "*" || list[list.Count - 2] == "/" || list[list.Count - 2] == "+" || list[list.Count - 2] == "-" || list[list.Count - 2] == "%"))
                {
                    newList.Add(list[list.Count - 2]);
                }
                
               
				if (list[list.Count - 1] != "X")
				{
					newList.Add(list[list.Count - 1]);
				
				}
				
                if (newList.Count!=0)
                {	
                    
                    finalList.Add(ProcessNumber(newList).ToString());                 
                }
                else
                    finalList.Add("0");

                    
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i] == "X")
                    {
                        finalList.Add(ProcessVariable(list).ToString());
                        
                    }
                }
  
            }
            else
            {
                
                for (int i = 0; i < list.Count; i++)
                {
                    if( list[i] != "X" && list[i] != "*" && list[i] != "/" && list[i] != "+"&& list[i] != "-" &&list[i] != "%")
                    {
						try
						{
							int number = Int32.Parse(list[i]);

						}
						catch (FormatException)
						{
							Console.WriteLine("{0}: Bad Format", list[i]);
						}
						catch (OverflowException)
						{
							Console.WriteLine("{0}: Overflow", list[i]);
						}
                    }
                }
                finalList.Add(ProcessNumber(list).ToString());
                finalList.Add("0");
            }
                           
           return finalList;
        }
        public int SolveFirstEqn(List <string> leftlist, List<string> rightList)
        {
            int result =0;
            int a, b;
            a=ProcessVariable(leftlist);
            b=ProcessNumber(rightList);
            result = b / a;
            return result;
            
        }
        public int ProcessVariable (List<string> list)

        {
            int a = 0;
            for (int i = 0; i < list.Count; i++)
            {
               
                if (list[i] == "X")
                {

                    if (i != 0)
                    {
                        if (list[i - 1] != "*" && list[i - 1] != "/" && list[i - 1] != "+" && list[i - 1] != "-" && list[i - 1] != "%")
                        {
                            if (i - 1 > 0)
                            {
                                if (list[i - 2] == "-")
                                {
                                    a += (0 - Convert.ToInt32(list[i - 1]));
                                }
                                else
                                {
                                    a += Convert.ToInt32(list[i - 1]);
                                }
                            }
                        }
                        else if (list[i - 1] == "-")
                        {
                            a += -1;
                        }
                                                                                       
                    } 
                     
                    else
                    {
                        if (list[i] == "-")
                           a += -1;
                        else
                           a += 1;
                         
                    }
                                
                }
            }
            return a;
        }
        public int ProcessNumber (List <string> list)
        {
            
            int result = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] !="*" && list[i] != "/" && list[i] != "+" && list[i] != "-" && list[i] != "%")
                {

                    while (i + 2 < list.Count && (list[i + 1].ToString() == "*" || list[i + 1].ToString() == "/" || list[i + 1].ToString() == "%"))
                    {
                        result = MulDivNumber(list[i], list[i + 1], list[i + 2]);
                        list.RemoveRange(i+1, 2);
                        list[i] = result.ToString();

                    }

                }

            }
            for (int j = 0; j < list.Count; j++)
            { 
                if (list[j] != "*" && list[j] != "/" && list[j] != "+" && list[j] != "-" && list[j] != "%")
                {
                    while (j + 2 < list.Count && (list[j + 1].ToString() == "+" || list[j + 1].ToString() == "-"))
                    {
                        result = SumSubNumber(list[j], list[j + 1], list[j + 2]);
                        list.RemoveRange(j + 1, 2);
                        list[j] = result.ToString();
                    }
                }
            }

            return result;    
        }
        public int MulDivNumber (string a, string opr, string b)
        {
            int result =0;
           
            if (opr == "*")
            {
                result = Convert.ToInt32(a) * Convert.ToInt32(b);
            }
            if (opr == "/")
            {
                result = Convert.ToInt32(a) / Convert.ToInt32(b);
            }
            if (opr == "%")
            {
                result = Convert.ToInt32(a) % Convert.ToInt32(b);
            }
         
            return result;
        }
        public int SumSubNumber (string a, string opr, string b)
        {
            int result =0;
           
            if (opr == "+")
            {
                result = Convert.ToInt32(a) + Convert.ToInt32(b);
            }
            if (opr == "-")
            {
                result = Convert.ToInt32(a) - Convert.ToInt32(b);
            }
          return result;
        }
    }
}
