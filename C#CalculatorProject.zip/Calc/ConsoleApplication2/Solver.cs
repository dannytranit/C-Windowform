﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Solver
    {

        public int Solve(string equation)
        {
            int result = 0;
			equation = equation.ToUpper();
		    equation = equation.Replace("++", "+").Replace("--", "-").Replace("+-", "-").Replace("-+", "-");
			if (!(equation.Contains("X")) || !(equation.Contains("=")))
			{
				throw new System.ArgumentException("Not correct equation formation! Equation {0} needs to have variabel e.g: X and = sign", equation);
			}


            Char seperator = '=';
			string leftEqn;
			string rightEqn;
            string[] subStrings = equation.Split(seperator);
            leftEqn = subStrings[0];
            rightEqn = subStrings[1];


            Creator creator = new Creator();
            List<string> leftList = null;
            List<string> rightList = null;
            leftList = creator.GetNumberOrOperator(leftEqn);
			rightList = creator.GetNumberOrOperator(rightEqn);
			
			Function func = new Function();
            //result = func.SolveFirstEqn(leftList, rightList);

            result = func.SolveSecondEqn(leftList, rightList);

            return result;
        }
    }
}
