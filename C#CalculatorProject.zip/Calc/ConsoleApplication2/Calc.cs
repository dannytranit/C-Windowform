﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Calc
    {
        static void Main(string[] args)
        {
            int result;
            string equation;

            equation = Console.ReadLine();

            Solver solver = new Solver();
            result = solver.Solve(equation);
            Console.WriteLine("X= " + result);
            Console.Read();

        }
    }
               
        
}
