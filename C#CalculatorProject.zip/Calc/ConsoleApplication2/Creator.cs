﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Creator
    {
      

        public List <string> GetNumberOrOperator(string expr)
        {
            List<string> stringList = new List<string>();
            string noWhiteSpaceEquation = null;
            for (int i = 0; i < expr.Length; i++)
            {
                if (expr[i] != ' ')

                {
                    noWhiteSpaceEquation += expr[i];
                }

            }
            string temp = "";
            for (int i = 0; i < noWhiteSpaceEquation.Length; i++)
            {
               
                if (Char.IsDigit(noWhiteSpaceEquation[i]))
                {
                    temp = temp + noWhiteSpaceEquation[i];

                    while ((i + 1) < noWhiteSpaceEquation.Length && (Char.IsDigit(noWhiteSpaceEquation[i + 1])))
                    {
                        i++;
                        temp = temp + noWhiteSpaceEquation[i];

                    }
                    stringList.Add(temp);
                    temp = "";
                }
                else if (Char.IsLetter(noWhiteSpaceEquation[i]))
                {
                    stringList.Add(noWhiteSpaceEquation[i].ToString());
                }
                else 
                {
                    
                    stringList.Add(noWhiteSpaceEquation[i].ToString());

                } 

            }

            return stringList;
        }
        
    }
}
